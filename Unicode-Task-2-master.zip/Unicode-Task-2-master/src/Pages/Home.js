

export default function Home() {
    return(
        <div className="container flex flex-row-reverse">

            <div className="text-holder w-full mx-auto mt-24">
                <h1 className="text-9xl text-center"><strong>Welcome</strong> To</h1>
                <h2 className="text-7xl text-center"> <span>my</span> <strong></strong>Project !!! </h2>
            </div>
        </div>
    )
};
